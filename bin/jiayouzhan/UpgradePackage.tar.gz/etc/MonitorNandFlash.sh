#!/bin/sh

NandFlashAvailableSpace=`df | grep /dev/mtdblock4 | awk {'print $4'}`
DirList=`ls -c -r /mnt`

if [ $NandFlashAvailableSpace -lt 153600 ];then
    for DirName in $DirList 
    do
        rm -rf /mnt/$DirName
        NandFlashAvailableSpace=`df | grep /dev/mtdblock4 | awk {'print $4'}`
        if [ $NandFlashAvailableSpace -gt 256000 ];then
            exit 0
        fi
    done
fi
